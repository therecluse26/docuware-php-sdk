export const theme: string;
